def ask_ai(prompt, phone=None):
    # Тут будет OpenAI или другой LLM-сервис (пока демонстрация)
    return f"🤖 Диамир-ИИ: ваш вопрос — «{prompt}». Это демонстрационный ответ."
