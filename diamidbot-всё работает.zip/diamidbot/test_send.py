import config
print(dir(config))  # Посмотрим все переменные, что есть в модуле
